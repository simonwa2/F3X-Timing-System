Drill file format is 4.4
